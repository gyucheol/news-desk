#!/usr/bin/env bash
# 가벼운 준비(음성 인식·AI 모델 없이): 파이썬 환경(pillow, numpy)과 글꼴(Pretendard, Noto Sans KR, 모두 OFL)을 fonts/에 받는다.
# 녹음 싱크가 필요할 때: ./setup.sh (faster-whisper large-v3 약 2.9GB 추가)
# AI 이미지가 필요할 때: WITH_AI=1 ./setup.sh (약 6.5GB 추가, AMX CPU 확인: grep -o amx_bf16 /proc/cpuinfo)
set -euo pipefail
cd "$(dirname "$0")"
command -v ffmpeg >/dev/null || { echo "ffmpeg not found"; exit 1; }
[ -x venv/bin/python ] || python3 -m venv venv
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q pillow numpy
mkdir -p fonts work
for w in Regular Medium SemiBold Bold ExtraBold Black; do
  [ -s "fonts/Pretendard-$w.otf" ] || curl -sSf -o "fonts/Pretendard-$w.otf" \
    "https://cdn.jsdelivr.net/npm/pretendard@1.3.9/dist/public/static/Pretendard-$w.otf"
done
[ -s fonts/NotoSansKR-VF.ttf ] || curl -sSfL -o fonts/NotoSansKR-VF.ttf \
  "https://raw.githubusercontent.com/google/fonts/main/ofl/notosanskr/NotoSansKR%5Bwght%5D.ttf"
echo "준비 끝: $(pwd)"
echo "썸네일 만들 때: export FONT_DIR=$(pwd)/fonts 후 $(pwd)/venv/bin/python 으로 실행"
